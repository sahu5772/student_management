<?php
require_once("config.php");
$allData = $_REQUEST;
// echo "<pre>";
// print_r($allData);
// die();
if($_SERVER['REQUEST_METHOD']=='POST' && isset($allData['submit_country'])) {
    if($allData['country_name'] && ($allData['status'] == 0 OR $allData['status'])) {
        $in_country= "INSERT INTO `country` (`country_name`,`status`) values ('".$allData['country_name']."', ".$allData['status'].")";
        $con->query($in_country);
        // print_r($in_country);
        // die;
        $countryId = $con->insert_id;
        
        foreach($allData['state_name'] as $key => $stateName) {
            $stateName = $stateName;
            $status=$allData['status'][$key];
            // $nos = $formData['nos'][$key];
           
            $insstate = "INSERT INTO `state`(`country_id`, `state_name`,`status`) values($countryId, '$stateName',$status)";
            $con->query($insstate);

            // print_r($insSection);
        }
        // die;

        $_SESSION['success']="country added successfully...";
        header("Location:manage-country.php");
    } else {
        $_SESSION['error']="All * fields are required.";
        $_SESSION['country_name']=$allData['country_name'];
        $_SESSION['status']=$allData['status'];
        header("Location:add-country.php");
    }
}elseif($_SERVER['REQUEST_METHOD']=='POST' && isset($allData['submit_state'])) {
        if($allData['state_name'] && ($allData['status'] == 0 OR $allData['status'])) {
            $in_state= "INSERT INTO `state` (`state_name`,`status`) values ('".$allData['state_name']."', ".$allData['status'].")";
            $con->query($in_state);
            // print_r($in_state);
            // die;
            $_SESSION['success']="state added successfully...";
            header("Location:manage-state.php");
        } else {
            $_SESSION['error']="All * fields are required.";
            $_SESSION['state_name']=$allData['state_name'];
            $_SESSION['status']=$allData['status'];
            header("Location:add-state.php");
        }

}elseif($_SERVER['REQUEST_METHOD']=='POST' && isset($allData['submit_city'])) {
    if($allData['city_name'] && ($allData['status'] == 0 OR $allData['status'])) {
        $in_city= "INSERT INTO `city` (`city_name`,`status`) values ('".$allData['city_name']."', ".$allData['status'].")";
        $con->query($in_city);
        // print_r($in_city);
        // die;
        $_SESSION['success']="city added successfully...";
        header("Location:manage-city.php");
    } else {
        $_SESSION['error']="All * fields are required.";
        $_SESSION['city_name']=$allData['city_name'];
        $_SESSION['status']=$allData['status'];
        header("Location:add-city.php");
    } 
}else {
    die("Un-Authorized Access....");
}
?>